"use strict";

module.exports = {
  secretOrkey: "secret"
};