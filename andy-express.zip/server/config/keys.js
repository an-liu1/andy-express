module.exports = {
  secretOrkey: "secret"
};
